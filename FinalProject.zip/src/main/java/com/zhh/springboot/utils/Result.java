package com.zhh.springboot.utils;


//统一的 REST响应对象。 这个对象里包含是否成功，错误信息，以及数据。
//Result 对象是一种常见的 RESTFUL 风格返回的 json 格式，里面可以有错误代码，错误信息和数据。
public class Result {

    private static final int SUCCESS_CODE = 0;
    private static final int FAIL_CODE=1;

    int code;
    String message;
    Object data;

    public Result(int code,String message,Object data){
        this.code=code;
        this.message=message;
        this.data=data;
    }

    public static Result success(){
        return new Result(SUCCESS_CODE,null,null );
    }

    public static  Result success(String message){
        return new Result(SUCCESS_CODE,message,null);
    }

    public static  Result success(Object data){
        return new Result(SUCCESS_CODE,null,data);
    }

    public static  Result fail(String message){
        return new Result(FAIL_CODE,message,null);
    }
    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }



}
