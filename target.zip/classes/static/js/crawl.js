$(function(){
    $("#startBtn").click(start_crawl);
    $(".close").click(close);
});

function start_crawl() {
    $("#hintModal").modal("show");
    $.post(
        CONTEXT_PATH + "/crawl/start",
        function(data) {
            data = $.parseJSON(data);
            if(data.code == 0) {
                $("#hintBody").text("CRAWL SUCCESS!");
                $(".close").model("show");
                setTimeout(function(){
                    $("#hintModal").modal("hide");
                    location.reload();
                }, 2000);
            } else {
                $("#hintBody").text(data.msg);
            }

        }
    );
}

function close() {
    $("#hintModal").modal("hide");
}
