//codes.js
system = require('system')
address = system.args[1];
var page = require('webpage').create();
var url = address;

page.settings.resourceTimeout = 1000*10; // 10 seconds
page.settings.userAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:87.0) Gecko/20100101 Firefox/87.0';
page.onResourceTimeout = function(e) {
    console.log(page.content);
    phantom.exit(1);
};

page.open(url, function (status) {
    //Page is loaded!
    if (status !== 'success') {
        console.log('Unable to post!');
    } else {
        console.log(page.content);
        // var pageNum = document.querySelector("span.fp-text").getElementsByTagName("i").text();
        // var nextPage = document.querySelector("a.fp-text");
        // page.wait();
        // console.log(
        //     page.evaluate(function() {
        //         nextPage.click();
        //         return page.content;
        //     })
        // )
    }
    phantom.exit();
});